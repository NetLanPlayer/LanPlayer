package de.quippy.sidplay.libsidplay;

public class Config {

	public final static String PACKAGE_NAME = "libsidplay";

	public final static String PACKAGE_VERSION = "2.1.1";

	public final static String S_A_WHITE_EMAIL = "sidplay2@yahoo.com";

}
